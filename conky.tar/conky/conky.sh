#!/bin/sh
(sleep 4s && conky) &exit 0
